Exe files require MATLAB Runtime version 9.2 (R2017a).   

To download the Windows 64-bit version of the MATLAB Runtime for R2017a 
from the MathWorks Web site navigate to

   http://www.mathworks.com/products/compiler/mcr/index.html
   



